;
<?php $__env->startSection('content'); ?>
    <div id="main-content-wp" class="clearfix category-product-page">
        <div class="wp-inner">
            <div class="secion" id="breadcrumb-wp">
                <div class="secion-detail">
                    <ul class="list-item clearfix">
                        <li>
                            <a href="" title="">Trang chủ</a>
                        </li>
                        <li>
                            <a href="" title=""><?php echo e($cat_name); ?></a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="main-content fl-right">
                <div class="section" id="list-product-wp">
                    <div class="section-head clearfix">
                        <h3 class="section-title fl-left"><?php echo e($cat_name); ?></h3>
                        <div class="filter-wp fl-right">
                            <p class="desc">Hiển thị <?php echo e($count[0]); ?> trên <?php echo e($count[1]); ?> sản phẩm</p>
                            <div class="form-filter">
                                <form>
                                    <select name="sort">
                                        <option value="0">Sắp xếp</option>
                                        <option <?php echo e(request()->sort == 'a-z' ? 'selected' : ''); ?> value="a-z">Từ A-Z</option>
                                        <option <?php echo e(request()->sort == 'z-a' ? 'selected' : ''); ?> value="z-a">Từ Z-A</option>
                                        <option <?php echo e(request()->sort == 'high-to-low' ? 'selected' : ''); ?> value="high-to-low">Giá cao
                                            xuống thấp</option>
                                        <option <?php echo e(request()->sort == 'low-to-high' ? 'selected' : ''); ?> value="low-to-high">Giá
                                            thấp lên cao</option>
                                    </select>
                                    <button type="submit">Lọc</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="section-detail">
                        <?php if($products->count() > 0): ?>
                            <ul class="list-item clearfix">
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="<?php echo e(route('user.detail.product', $item->id)); ?>" title=""
                                            class="thumb">
                                            <img src="<?php echo e(asset($item->images)); ?>">
                                        </a>
                                        <a href="<?php echo e(route('user.detail.product', $item->id)); ?>" title=""
                                            class="product-name"><?php echo e($item->name); ?></a>
                                        <div class="price">
                                            <span
                                                class="new"><?php echo e(number_format($item->price, 0, 0, '.')); ?>đ</span>
                                            <span class="old">20.900.000đ</span>
                                        </div>
                                        <div class="action clearfix">
                                            <form action="<?php echo e(route('cart.add', $item->id)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="num-order" value="1" id="num-order">
                                                <button type="submit" title="Thêm giỏ hàng" class="add-cart fl-left">Thêm
                                                    giỏ
                                                    hàng</button>
                                            </form>
                                            <a href="?page=checkout" title="Mua ngay" class="buy-now fl-right">Mua ngay</a>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php else: ?>
                            <p>không tìm thấy bất kì sản phẩm nào</p>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="section" id="paging-wp">
                    <div class="section-detail">
                        <?php echo e($products->links()); ?>

                    </div>
                </div>
            </div>
            <?php echo $__env->make('user.product.componmentSidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/customer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\unitop.vn\Laravel\unimark\resources\views/user/product/category.blade.php ENDPATH**/ ?>