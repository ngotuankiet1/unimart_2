<div class="sidebar fl-left">
    <div class="section" id="category-product-wp">
        <div class="section-head">
            <h3 class="section-title">Danh mục sản phẩm</h3>
        </div>
        <div class="secion-detail">
            <ul class="list-item">
                <?php $__currentLoopData = $list_cat_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $slug = $cat
                ?>
                    <?php if($cat->lever == 1): ?>
                        <li>
                            <a href="<?php echo e(route('user.catrgory',$cat->id)); ?>" title=""><?php echo e($cat->name); ?></a>
                            <ul class="sub-menu">
                                <?php $__currentLoopData = $list_cat_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat_sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($cat_sub->lever == 2 && $cat_sub->parent_cat == $cat->id): ?>
                                        <li>
                                            <a href="<?php echo e(route('user.catrgory',$cat_sub->id)); ?>" title=""><?php echo e($cat_sub->name); ?></a>
                                        </li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
    <div class="section" id="selling-wp">
        <div class="section-head">
            <h3 class="section-title">Sản phẩm bán chạy</h3>
        </div>
        <div class="section-detail">
            <ul class="list-item">
                <?php $__currentLoopData = $list_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="clearfix">
                        <a href="<?php echo e(route('user.detail.product',$item->id)); ?>" title="" class="thumb fl-left">
                            <img src="<?php echo e(asset($item->images)); ?>" alt="">
                        </a>
                        <div class="info fl-right">
                            <a href="<?php echo e(route('user.detail.product',$item->id)); ?>" title="" class="product-name"><?php echo e($item->name); ?></a>
                            <div class="price">
                                <span class="new"><?php echo e(number_format($item->price,0,0,'.')); ?>đ</span>
                                <span class="old">7.190.000đ</span>
                            </div>
                            <a href="" title="" class="buy-now">Mua ngay</a>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
    <div class="section" id="banner-wp">
        <div class="section-detail">
            <a href="" title="" class="thumb">
                <img src="public//user/images/banner.png" alt="">
            </a>
        </div>
    </div>
</div>
<?php /**PATH D:\xampp\htdocs\unitop.vn\Laravel\unimark\resources\views/user/components/sidebar.blade.php ENDPATH**/ ?>