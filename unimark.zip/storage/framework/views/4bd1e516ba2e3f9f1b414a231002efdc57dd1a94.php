;
<?php $__env->startSection('content'); ?>
    <div id="main-content-wp" class="cart-page">
        <div class="section" id="breadcrumb-wp">
            <div class="wp-inner">
                <div class="section-detail">
                    <ul class="list-item clearfix">
                        <li>
                            <a href="?page=home" title="">Trang chủ</a>
                        </li>
                        <li>
                            <a href="" title="">Giỏ hàng</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div id="wrapper" class="wp-inner clearfix">
            <?php if(Cart::count() > 0): ?>
                <div class="section" id="info-cart-wp">
                    <div class="section-detail table-responsive">
                        <form action="<?php echo e(route('cart.update')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <table class="table">
                                <thead>
                                    <tr>
                                        <td>Mã sản phẩm</td>
                                        <td>Ảnh sản phẩm</td>
                                        <td>Tên sản phẩm</td>
                                        <td>Giá sản phẩm</td>
                                        <td>Số lượng</td>
                                        <td colspan="2">Thành tiền</td>
                                        <td>Tác vụ</td>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $order = 0;
                                    ?>
                                    <?php $__currentLoopData = Cart::content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $order++;
                                        ?>
                                        <tr>
                                            <td><?php echo e($order); ?></td>
                                            <td>
                                                <a href="" title="" class="thumb">
                                                    <img src="<?php echo e(asset($item->options->images)); ?>" alt="">
                                                </a>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('user.detail.product', $item->id)); ?>" title=""
                                                    class="name-product"><?php echo e($item->name); ?></a>
                                            </td>
                                            <td><?php echo e(number_format($item->price, 0, ',', '.')); ?>đ</td>
                                            <td>
                                                <input type="number" min="1" max="10" name="qty" value="<?php echo e($item->qty); ?>"
                                                    class="num-order">
                                                <input type="hidden" value="<?php echo e($item->rowId); ?>" name="rowId_cart"
                                                    class="form_control">
                                            </td>
                                            <td><?php echo e(number_format($item->total, 0, ',', '.')); ?>đ</td>
                                            <td colspan="3">
                                                <a onclick="return confirm('Bạn có chắc muốn xóa?')"
                                                    href="<?php echo e(route('cart.delete', $item->rowId)); ?>" title="Delete"
                                                    class="del-product"><i class="fa fa-trash-o"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="7">
                                            <div class="clearfix">
                                                <p id="total-price" class="fl-right">Tổng giá:
                                                    <span><?php echo e(Cart::total()); ?>đ</span>
                                                </p>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="7">
                                            <div class="clearfix">
                                                <div class="fl-right">
                                                    <input type="submit" id="update-cart" value="Cập nhật giỏ hàng">
                                                    <?php
                                                        $customer_id = Session::get('customer_id');
                                                    ?>
                                                    <?php if($customer_id != null): ?>
                                                        <a href="<?php echo e(route('cart.checkout')); ?>" title=""
                                                            id="checkout-cart">Thanh toán</a>
                                                    <?php else: ?>
                                                        <a href="<?php echo e(route('cart.checkoutLogin')); ?>" title=""
                                                            id="checkout-cart">Thanh toán</a>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                </tfoot>
                            </table>
                        </form>
                    </div>
                </div>
                <div class="section" id="action-cart-wp">
                    <div class="section-detail">
                        <p class="title">Click vào <span>“Cập nhật giỏ hàng”</span> để cập nhật số lượng. Nhập vào
                            số
                            lượng <span>0</span> để xóa sản phẩm khỏi giỏ hàng. Nhấn vào thanh toán để hoàn tất mua hàng.
                        </p>
                        <a href="<?php echo e(url('/')); ?>" title="" id="buy-more">Mua tiếp</a><br />
                        <a href="<?php echo e(route('cart.delete', ['rowId' => 'all'])); ?>" title="" id="delete-cart">Xóa giỏ
                            hàng</a>
                    </div>
                </div>
            <?php else: ?>
                <p style="color: red">không có sản phẩm</p>
                <a href="<?php echo e(url('/')); ?>">Trở về trang chủ</a>
            <?php endif; ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/customer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\unitop.vn\Laravel\unimark\resources\views/user/cart/show.blade.php ENDPATH**/ ?>