<?php $__env->startSection('content'); ?>
    <div class="main-content fl-right">
        <div class="section" id="list-product-wp">
            <div class="section-head">
                <h3 class="section-title">Kết quả tìm kiếm</h3>
            </div>
            <div class="section-detail">
                <ul class="list-item clearfix">
                    <?php if($products->total() > 0): ?>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a href="<?php echo e(route('user.detail.product', $item->id)); ?>" title="" class="thumb">
                                    <img src="<?php echo e(asset($item->images)); ?>">
                                </a>
                                <a href="<?php echo e(route('user.detail.product', $item->id)); ?>" title=""
                                    class="product-name"><?php echo e($item->name); ?></a>
                                <div class="price">
                                    <span class="new"><?php echo e(number_format($item->price, 0, 0, '.')); ?>đ</span>
                                    <span class="old">20.900.000đ</span>
                                </div>
                                <div class="action clearfix">
                                    <form action="<?php echo e(route('cart.add', $item->id)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="num-order" value="1" id="num-order">
                                        <button type="submit" title="Thêm giỏ hàng" class="add-cart fl-left">Thêm giỏ
                                            hàng</button>
                                    </form>
                                    <a href="?page=checkout" title="Mua ngay" class="buy-now fl-right">Mua ngay</a>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr>
                            <p class="bg-white">không có dữ liệu</p>
                        </tr>
                    <?php endif; ?>
                </ul>
                    <?php echo e($products->links()); ?>

            </div>
        </div>
    </div>
    <?php echo $__env->make('user.components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/customer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\unitop.vn\Laravel\unimark\resources\views/user/product/search.blade.php ENDPATH**/ ?>