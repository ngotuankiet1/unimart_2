;
<?php $__env->startSection('content'); ?>
    <div style="text-align: center" class="review_payment">
        <img style="margin: 0px auto;" src="<?php echo e(asset('uploads/cart/cart.png')); ?>" alt="">
        <h1>Cảm ơn bạn đã mua sản phẩm tại Unimart</h1>
        <h3>Chúng tôi sẽ xác nhận và liên hệ sau với quý khách sớm nhất</h3>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/customer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\unitop.vn\Laravel\unimark\resources\views/user/cart/handcart.blade.php ENDPATH**/ ?>