;
<link href="<?php echo e(asset('user/css/import/checkout_log.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->startSection('content'); ?>
    <?php echo e(session('id')); ?>

    <div id="wrapper" class="wp-inner clearfix">
        <div class="login-form">
            <form action="<?php echo e(route('user.login')); ?>" id="form-login" method="POST">
                <?php echo csrf_field(); ?>
                <h1 class="form-heading">Đăng nhập</h1>
                <div class="form-group">
                    <i class="fa fa-user" aria-hidden="true"></i>
                    <input type="text" name="username" class="form-input" placeholder="Tên đăng nhập">
                </div>
                <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="form-group">
                    <i class="fa fa-key" aria-hidden="true"></i>
                    <input type="password" name="password" class="form-input" placeholder="Mật khẩu">
                    <div id="eye">
                        <i class="fa fa-eye" aria-hidden="true"></i>
                    </div>
                </div>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <br>
                <span>
                    <input type="checkbox" class="checkbox">
                    Ghi nhớ mật khẩu
                </span>
                <input type="submit" value="Đăng nhập" class="form-submit">
                <?php if(session('info')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('info')); ?>

                    </div>
                <?php endif; ?>
            </form>
        </div>
        <div class="or">OR</div>

        <div class="reg-form">
            <?php if(session('status')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
            <form action="<?php echo e(route('user.add')); ?>" method="post" id="form-login">
                <?php echo csrf_field(); ?>
                <h1 class="form-heading">Đăng kí</h1>
                <div class="form-group">
                    <i class="fa fa-user" aria-hidden="true"></i>
                    <input type="text" name="customer_name" class="form-input" placeholder="Tên đăng nhập">

                </div>
                <?php $__errorArgs = ['customer_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <div class="form-group">
                    <i class="fa fa-envelope" aria-hidden="true"></i>
                    <input type="email" name="customer_email" placeholder="Email" class="form-input" />
                </div>
                <?php $__errorArgs = ['customer_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <div class="form-group">
                    <i class="fa fa-key" aria-hidden="true"></i>
                    <input type="password" name="customer_pass" class="form-input" placeholder="Mật khẩu">
                    <div id="eye1">
                        <i class="fa fa-eye" aria-hidden="true"></i>
                    </div>
                </div>
                <?php $__errorArgs = ['customer_pass'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="form-group">
                    <i class="fa fa-key" aria-hidden="true"></i>
                    <input type="password" name="comfirm_password" class="form-input" placeholder="Xác nhận mật khẩu">
                    <div id="eye2">
                        <i class="fa fa-eye" aria-hidden="true"></i>
                    </div>

                </div>
                <?php $__errorArgs = ['comfirm_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <div class="form-group">
                    <i class="fa fa-phone" aria-hidden="true"></i>
                    <input type="text" name="customer_phone" class="form-input" placeholder="Số điện thoại">

                </div>
                <?php $__errorArgs = ['customer_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <input type="submit" name="btn-reg" value="Đăng Ký" class="form-submit">
            </form>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('user/js/checkout_login.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/customer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\unitop.vn\Laravel\unimark\resources\views/user/cart/checkout_login.blade.php ENDPATH**/ ?>