<?php $__env->startSection('content'); ?>
    <div id="content" class="container-fluid">
        <div class="card">
            <?php if(session('status')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
            <div class="card-header font-weight-bold d-flex justify-content-between align-items-center">
                <h5 class="m-0 ">Danh sách đơn hàng</h5>
                <div class="form-search form-inline">
                    <form action="#">
                        <input type="" class="form-control form-search" name="keyword" placeholder="Tìm kiếm">
                        <input type="submit" name="btn-search" value="Tìm kiếm" class="btn btn-primary">
                    </form>
                </div>
            </div>
            <div class="card-body">
                <div class="analytic">
                    <a href="<?php echo e(request()->fullUrlWithQuery(['status' => 'active'])); ?>" class="text-primary">Tất cả<span
                            class="text-muted">(<?php echo e($count[0]); ?>)</span></a>
                    <a href="<?php echo e(request()->fullUrlWithQuery(['status' => 'trash'])); ?>" class="text-primary">Thùng
                        rác<span class="text-muted">(<?php echo e($count[1]); ?>)</span></a>
                </div>
                <div class="form-action form-inline py-3">
                    <select class="form-control mr-1" id="">
                        <option>Chọn</option>
                        <?php $__currentLoopData = $list_act; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($k); ?>"><?php echo e($v); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <input type="submit" name="btn-search" value="Áp dụng" class="btn btn-primary">
                </div>
                <table class="table table-striped table-checkall">
                    <thead>
                        <tr>
                            <th>
                                <input type="checkbox" name="checkall">
                            </th>
                            <th scope="col">#</th>
                            <th scope="col">Mã</th>
                            <th scope="col">Khách hàng</th>
                            
                            <th scope="col">Giá trị</th>
                            <th scope="col">Trạng thái</th>
                            <th scope="col">Thời gian</th>
                            <th scope="col">Tác vụ</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $order = 0;
                        ?>
                        <?php $__currentLoopData = $all_order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $order++;
                            ?>
                            <tr>
                                <td>
                                    <input type="checkbox">
                                </td>
                                <td><?php echo e($order); ?></td>
                                <td><?php echo e($item->order_code); ?></td>
                                <td>
                                    <?php echo e($item->shipping_name); ?> <br>
                                    <?php echo e($item->shipping_phone); ?> <br>
                                </td>
                                
                                <td><?php echo e($item->order_total); ?>đ</td>
                                <td>
                                    <span
                                        class="badge badge-warning"><?php echo e($item->order_status == 0 ? 'Đang xử lí' : ''); ?></span>
                                    <span
                                        class="badge badge-primary"><?php echo e($item->order_status == 1 ? 'Đang giao hàng' : ''); ?></span>
                                    <span
                                        class="badge badge-success"><?php echo e($item->order_status == 2 ? 'Hoàn thành' : ''); ?></span>
                                    <span
                                        class="badge badge-danger"><?php echo e($item->order_status == 3 ? 'Hủy đơn' : ''); ?></span>
                                </td>
                                <td>26:06:2020 14:00</td>
                                <td>
                                    <a href="<?php echo e(route('order.detail', $item->order_id)); ?>"
                                        class="btn btn-success btn-sm rounded-0 text-white" type="button"
                                        data-toggle="tooltip" data-placement="top" title="Edit"><i
                                            class="fa fa-edit"></i></a>
                                    <a href="<?php echo e(route('order.delete', $item->order_id)); ?>"
                                        onclick="return confirm('Bạn có chắc muốn xóa?')"
                                        class="btn btn-danger btn-sm rounded-0 text-white" type="button"
                                        data-toggle="tooltip" data-placement="top" title="Delete"><i
                                            class="fa fa-trash"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo e($all_order->links()); ?>

            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/admins', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\unitop.vn\Laravel\unimark\resources\views/admins/order/show.blade.php ENDPATH**/ ?>