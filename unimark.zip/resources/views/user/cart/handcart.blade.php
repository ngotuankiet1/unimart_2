@extends('layouts/customer');
@section('content')
    <div style="text-align: center" class="review_payment">
        <img style="margin: 0px auto;" src="{{asset('uploads/cart/cart.png')}}" alt="">
        <h1>Cảm ơn bạn đã mua sản phẩm tại Unimart</h1>
        <h3>Chúng tôi sẽ xác nhận và liên hệ sau với quý khách sớm nhất</h3>
    </div>
@endsection
